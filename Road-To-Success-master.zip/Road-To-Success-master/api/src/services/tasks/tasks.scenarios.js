export const standard = defineScenario({
  task: {
    one: {
      data: {
        status_id: 4271303,
        urgency: 775924,
        priority: 129201,
        date: '2022-11-16T19:53:37.717Z',
      },
    },
    two: {
      data: {
        status_id: 4696108,
        urgency: 7702247,
        priority: 7754791,
        date: '2022-11-16T19:53:37.717Z',
      },
    },
  },
})
