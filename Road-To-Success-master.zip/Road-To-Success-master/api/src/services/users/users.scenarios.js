export const standard = defineScenario({
  user: {
    one: { data: { email: 'String7886125' } },
    two: { data: { email: 'String433170' } },
  },
})
