import RoTestPage from './RoTestPage'

export const generated = () => {
  return <RoTestPage />
}

export default {
  title: 'Pages/RoTestPage',
  component: RoTestPage,
}
