import ProfilePage from './ProfilePage'

export const generated = () => {
  return <ProfilePage />
}


export default {
  title: 'Pages/ProfilePage',
  component: ProfilePage,
}
