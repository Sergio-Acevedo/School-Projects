import BannerLayout from './BannerLayout'

export const generated = (args) => {
  return <BannerLayout {...args} />
}

export default {
  title: 'Layouts/BannerLayout',
  component: BannerLayout,
}
