// Define your own mock data here:
export const standard = (/* vars, { ctx, req } */) => ({
  ro: {
    id: 42,
  },
})
