export const standard = () => {
  return {
    //Events
  Events: [
    {title: 'sleep', start: '2022-12-22T19:00:00.000Z', end: '2022-12-23T19:00:00.000Z'},
    {title: 'Study', start: '2022-12-22T10:00:00.000Z', end: '2022-12-22T19:00:00.000Z'},
    {title: 'Work', start: '2022-12-22T19:00:00.000Z', end: '2022-12-23T19:00:00.000Z'},
    {title: 'Class', start: '2022-12-22T19:00:00.000Z', end: '2022-12-23T19:00:00.000Z'},
  ],
}}
