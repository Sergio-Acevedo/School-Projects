# 490 Project: Team Kenny
Will be working on UI for this project
<p>
<img src="https://media.tenor.com/NOncB1BUlccAAAAC/south-park-kenny-mccormick.gif">
</p>


Week 7 Report: 
- Designed: Calendar View, landing page, login & sign-up page, profile page
https://www.figma.com/file/6bBloA9K6vM1UxKBsksgo5/Task-Management-Mockups?node-id=0%3A1

Week 8 Report: 
- UI Team moved forward with my designs for the landing page, login & sign-up, Calendar View
- Edited Calendar View Mockup
- got familiar with Chakra UI
- Started writing code 


