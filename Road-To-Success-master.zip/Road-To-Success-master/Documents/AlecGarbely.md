Made this file

12/13/22
Worked on tests for AuthCallbackCell, AuthCallbackPage, LoginPage, NotFoundError, ResetPasswordPage.
This constitutes most of my contribution to the entire project, though for a few days before this I was an active participant in discussions and meetings regarding testing.
Also discussed minor issues with group members throughout the project.
