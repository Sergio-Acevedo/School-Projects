#                           Dhruvil Kansara CS490-103 "Road to Success"

### ```Sprint 1 (Oct19-Nov2)```
+ I worked on planning for the profile and Ui Designs I picked up profile page and Weekly calender work

+ Read a few tutorials so i can get a better understanding of redwood so we i knew how to approach the project

### ```Sprint 2 (Nov3-Nov16)```
+ moved profile page to in progress

+ and started working on it faced some issues with some errors but got advised  on how to fix it from my team on discord


### ```Sprint 3 (Nov17-Nov30)```
+ Worked on the weekly calendar page

+ Someone else ended up completing it

+ i went back to the profile page to complete it.


### ```Sprint 4 (Dec1-Dec14)```
+ Redesigned the  profile page to go with the new colors on the markdown page

+ worked on figuring out how the page to implement the API.

+ This is how the page looked after final day of UI work.


<br>
<!--<div id="header" align="center">-->
  <img src="https://cdn.discordapp.com/attachments/1034512610235797666/1051944033586516038/Screen_Shot_2022-12-12_at_2.29.49_PM.png"/>
</div>
<br>





* [Commit](https://github.com/dhruvilk/Road-To-Success/pull/36/commits/8d44e6a1449ac44f4a7094a1ea0bf990eeda216a#diff-ad53ce3f831bc815455b9f3d758cac8ee3b7ca43081f81aa13cd8a7c74e4d1a6)

* [Commit](https://github.com/dhruvilk/Road-To-Success/pull/36/commits/143077d77a8a83a606bf91050acf70f8cb5e6400)

* [Commit](https://github.com/dhruvilk/Road-To-Success/pull/64/commits/ebb9bf2fda180dbc3109fe3e383ffa74f972cb5b)
