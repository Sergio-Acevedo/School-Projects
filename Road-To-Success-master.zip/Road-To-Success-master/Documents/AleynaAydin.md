daily view: https://www.figma.com/file/3wDRDWZPdSLPP4g7JEphxa/day-view?node-id=0%3A1
created daily view of calendar including timeblocking and to-do lists

- displayed the date and time of day on top of the page

- time blocking schedule
    - time being tracked in time blocking schedule (google calendar feature)
    - can add events to schedule throughout day

- to do list
    - can add tasks and sections to list for daily priorities
    - add titles and desciptions to overall list

- sticky note
    - can include reminders for day

    - familiarized using chakra
    - created daily view component
    - inserted the header with date and time
    - added notes bar

    to do:
        - add time blocking schedule
        - edit format