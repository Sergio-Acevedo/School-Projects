
#                           Dhruvil Kansara CS490-103 "Road to Success"

### ```Sprint 1 (Oct19-Nov2)```
+ I initialized the repo and did everything. Next week idk what we'll do

+ For the week of 10/26 I am going to start working on the security aspect. We've figured out what we're going to use
which is auth0. I've been reading up on it and this thursday at night Team Kenny Security is meeting up to work on it

+ Did a bunch of reading on auth0.

+ Set up auth0 in a separate branch yesterday(10/29)

+ Today on 10/30 team security will hop on and put the finishing touches on auth0. Get a home page up and running, get login and registration done(10/30)

### ```Sprint 2 (Nov3-Nov16)```
+ Restarted our stuff from square 1 since we decided having two logins was kind of dumb

+ Week of 11/7 basically just struggled

+ Week of 11/14 we met with purab and figured out how it would work and actually got a login page up and running but it was in ts not js so uhhh yeah

### ```Sprint 3 (Nov17-Nov30)```
+ 11/17 got the js login stuff working

+ week of 11/21 i got the login button onto the landing page. it doesnt show logout or the user pfp like it should but eh nbd
+ 11/23 started registration stuff

+ 11/24 did nothing cuz thanksgiving duh

+ Had meeting about progress. With the help of mike we have a gorgeous login and registration functionality

### ```Sprint 4 (Dec1-Dec14)```
+ Did a bunch of merges. We've got a good looking landing page and functionalities. Tom and Sergio have told me to step back and relax and let them put finishing touches instead of me worrying for a day.

+ Meeting with purab about what security has left. im doing regex. Also meeting with purab and UI as it seems they have work to merge into master

+ Plan was changed. Tom and sergio will be working on regex, forgot password, email verification. I have been tasked with clean up by Purab. The following files were deleted within pull requests and commented out as to who had what.
- Appointmentlist.js
- Appointmentlistscell.js
- Appointmentlistscell.mock.js
- Appointmentlistscell.stories.js

Also certain branches older than 2 weeks were deleted. They are as follows:

**These were all stale and as directed by purab and at my discretion they were checked, merged into backup(which is a copy of Master), pull requested, and then deleted.**
- Lazar
- Appointmentitem
- Merge-test-branch
- Task_UI_Small_changes
- AppointmentList
- dailyview
- profile-branch
- progress
- securityjawn
- tasks_api
- banner

+ Purab and I went through and deleted unused and irrelevant files. I will not list them here but he will have them on his readme. Also certain imports in relevant files were commented out to show which files were not used.

+ Security team meeting with purab. Got forcing users to sign up with emails down. Sergio almost has forgot password down and tom is doing email verification. Also I added stuff to force users to make strong passwords
+ **Final update. The project is now as far as it will get. Some issues persist but this will be a fun thing for me to work on as a portfolio addition. All branches sans master have been deleted, all pull requests have been merged and/or closed. As of 12/13/2022 at 10:20PM we are ready to present. May God be with us.**

## Commits:
(**These are both minor and major commits but this does not include any merges or pull requests that I may have performed as repository owner.** )
  * [Commit 13](https://github.com/dhruvilk/Road-To-Success/commit/a8324dec9bc8202e1547b7cdecc6905a9e223d9e)
  * [Commit 12](https://github.com/dhruvilk/Road-To-Success/commit/ff83e065b4ebbf08e8107ac13999f5d433a8b563)
  * [Commit 11](https://github.com/dhruvilk/Road-To-Success/commit/3b8ab4c8b05e71178a37e1ef8fe21858fa452d8f)
  * [Commit 10](https://github.com/dhruvilk/Road-To-Success/commit/70793898f2fee75ef593e4ea79e1804d17326e58)
  * [Commit 9](https://github.com/dhruvilk/Road-To-Success/commit/c1abfa79f23a99def216e7414d95b316c215d019)
  * [Commit 8](https://github.com/dhruvilk/Road-To-Success/commit/ff6aa50224acbb4622ab6c20a124a6cfcd7c65bb)
  * [Commit 7](https://github.com/dhruvilk/Road-To-Success/commit/f4dfd82887df817605bc7bc55e7f246d945596a9)
  * [Commit 6](https://github.com/dhruvilk/Road-To-Success/commit/9c500aba76af0414f4d17bde5de46fb3f7944748)
  * [Commit 5](https://github.com/dhruvilk/Road-To-Success/commit/2769bd201465de0aee50d5b854687935978f0658)
  * [Commit 4](https://github.com/dhruvilk/Road-To-Success/commit/2d34846621a84562519c0e60bb2b8e45586c634a)
  * [Commit 3](https://github.com/dhruvilk/Road-To-Success/commit/baaf91f6fbe5831e01d14e480b5128d6924bc359)
  * [Commit 2](https://github.com/dhruvilk/Road-To-Success/commit/a87ee356f02013eef03841a8a88b051d93dea6a9)
  * [Commit 1](https://github.com/dhruvilk/Road-To-Success/commit/a02025bf9473eaedb6d3ea682513df5121ab91b3)
