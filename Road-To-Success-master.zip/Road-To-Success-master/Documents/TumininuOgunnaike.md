[x] Another UI member
[x] created readme
[x] created mockup for landing page , login and registration https://www.figma.com/file/xzKJtEMjY2Sg7HJhiMIRVf/landing-page?node-id=116%3A7 on figma
[x]oct 30 : started developing landing page
[x]oct 31 : fixed text colors
[x]oct 31 : fixed horizontal bar
[x]Nov 1 : created appointment item mockup https://www.figma.com/file/xzKJtEMjY2Sg7HJhiMIRVf/landing-page?node-id=0%3A1
[x]oct 1 : created appointmentItem


