
## Lazar Agoev Contribution
- Made this file. I'm in the Api team researching about the topic.
- Was able to create Client ID and API key from Google calendar. 
- Moved on to tasks assignment, created "tasks.js" and tasks.sdl.js"
- Wrote query "getUserTasksOfUrgency"
- Wrote query "allTasks" that is used for debugging
- Created UI page taskPage that was used by API team for debugging because the UI team hasn't created any pages yet
- Debugged "getByDate" query created by Shumsher
- Modified mutations for tasks queries
- Worked on the TasksCell, helped UI team with Front end
- Fixed couple bugs created by API tead when saving new tasks
- Made tasks be dysplayed in sorted order, first by urgency, then by priority
- Made tasks be dragable
- Made task change their location in the list when drop them
- Made tasks change their urgency and priority when dropped into a new location




